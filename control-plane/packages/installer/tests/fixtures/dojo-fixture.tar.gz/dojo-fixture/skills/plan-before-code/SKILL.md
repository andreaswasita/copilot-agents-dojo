---
name: plan-before-code
description: Fixture description for plan-before-code.
tier: practical
category: workflow
---
# plan-before-code
Fixture body for plan-before-code.
