---
name: autonomous-bug-fix
description: Fixture description for autonomous-bug-fix.
tier: practical
category: workflow
---
# autonomous-bug-fix
Fixture body for autonomous-bug-fix.
