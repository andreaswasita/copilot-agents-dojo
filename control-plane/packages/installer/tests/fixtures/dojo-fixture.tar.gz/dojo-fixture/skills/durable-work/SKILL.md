---
name: durable-work
description: Fixture description for durable-work.
tier: practical
category: workflow
---
# durable-work
Fixture body for durable-work.
