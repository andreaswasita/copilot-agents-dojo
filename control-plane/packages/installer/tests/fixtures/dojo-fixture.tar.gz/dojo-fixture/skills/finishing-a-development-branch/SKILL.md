---
name: finishing-a-development-branch
description: Fixture description for finishing-a-development-branch.
tier: practical
category: workflow
---
# finishing-a-development-branch
Fixture body for finishing-a-development-branch.
