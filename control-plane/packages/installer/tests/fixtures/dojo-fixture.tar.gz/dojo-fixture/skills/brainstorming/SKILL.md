---
name: brainstorming
description: Fixture description for brainstorming.
tier: practical
category: workflow
---
# brainstorming
Fixture body for brainstorming.
