---
name: verify-before-done
description: Fixture description for verify-before-done.
tier: practical
category: workflow
---
# verify-before-done
Fixture body for verify-before-done.
